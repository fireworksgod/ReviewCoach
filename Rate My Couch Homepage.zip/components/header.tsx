import Image from "next/image"
import Link from "next/link"

export function Header() {
  return (
    <header className="w-full h-[75px] bg-[#202020] border-b border-black/8 px-[50px] flex items-center justify-between">
      <div className="flex items-center">
        <Link href="/">
          <Image src="/images/logo.jpeg" alt="Rate My Coach Logo" width={60} height={60} className="object-contain" />
        </Link>
      </div>

      <div className="flex items-center gap-4">
        <button className="px-6 py-2.5 bg-[#202020] text-white font-medium border border-white/20 rounded transition-all duration-200 ease-in-out hover:scale-[1.03] hover:shadow-lg">
          Login
        </button>
        <Link href="/register">
          <button className="px-6 py-2.5 bg-white text-[#202020] font-medium rounded transition-all duration-200 ease-in-out hover:scale-[1.03] hover:shadow-lg">
            Register
          </button>
        </Link>
      </div>
    </header>
  )
}
