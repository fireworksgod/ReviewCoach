"use client"

import type React from "react"

import { useState, useRef } from "react"
import Image from "next/image"

export function RegisterForm() {
  const [userType, setUserType] = useState<{ athlete: boolean; coach: boolean }>({
    athlete: false,
    coach: false,
  })
  const [name, setName] = useState("")
  const [instagram, setInstagram] = useState("")
  const [email, setEmail] = useState("")
  const [verificationAnswer, setVerificationAnswer] = useState("")
  const [profilePic, setProfilePic] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [verificationError, setVerificationError] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setProfilePic(file)
      const url = URL.createObjectURL(file)
      setPreviewUrl(url)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate verification answer (case insensitive)
    const correctAnswer = "derek lunsford"
    if (verificationAnswer.trim().toLowerCase() !== correctAnswer) {
      setVerificationError(true)
      return
    }

    setVerificationError(false)
    setSubmitted(true)

    // Form data ready for backend
    const formData = {
      userType,
      name,
      instagram,
      email,
      verificationAnswer,
      profilePic,
    }
    console.log("Form submitted:", formData)
  }

  if (submitted) {
    return (
      <div className="w-full max-w-md bg-white rounded-lg shadow-lg p-8 text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-[#202020] mb-2">Registration Successful!</h2>
        <p className="text-[#666666]">Your account has been created. You can now login.</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md bg-white rounded-lg shadow-lg p-8">
      <h1 className="text-2xl font-bold text-[#202020] mb-6 text-center">Register</h1>

      {/* User Type Checkboxes */}
      <div className="mb-5">
        <label className="block text-sm font-medium text-[#202020] mb-2">I am a:</label>
        <div className="flex gap-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={userType.athlete}
              onChange={(e) => setUserType({ ...userType, athlete: e.target.checked })}
              className="w-5 h-5 rounded border-gray-300 text-[#202020] focus:ring-[#202020]"
            />
            <span className="text-[#202020]">Athlete</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={userType.coach}
              onChange={(e) => setUserType({ ...userType, coach: e.target.checked })}
              className="w-5 h-5 rounded border-gray-300 text-[#202020] focus:ring-[#202020]"
            />
            <span className="text-[#202020]">Coach</span>
          </label>
        </div>
      </div>

      {/* Name */}
      <div className="mb-5">
        <label htmlFor="name" className="block text-sm font-medium text-[#202020] mb-2">
          Name
        </label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#202020] focus:border-transparent transition-all"
          placeholder="Enter your full name"
        />
      </div>

      {/* Instagram */}
      <div className="mb-5">
        <label htmlFor="instagram" className="block text-sm font-medium text-[#202020] mb-2">
          Instagram
        </label>
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#666666]">@</span>
          <input
            type="text"
            id="instagram"
            value={instagram}
            onChange={(e) => setInstagram(e.target.value)}
            required
            className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#202020] focus:border-transparent transition-all"
            placeholder="username"
          />
        </div>
      </div>

      {/* Email */}
      <div className="mb-5">
        <label htmlFor="email" className="block text-sm font-medium text-[#202020] mb-2">
          Email
        </label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#202020] focus:border-transparent transition-all"
          placeholder="you@example.com"
        />
      </div>

      {/* Verification Question */}
      <div className="mb-5">
        <label htmlFor="verification" className="block text-sm font-medium text-[#202020] mb-2">
          Verification Question: Who won the Mr Olympia this year?
        </label>
        <input
          type="text"
          id="verification"
          value={verificationAnswer}
          onChange={(e) => {
            setVerificationAnswer(e.target.value)
            setVerificationError(false)
          }}
          required
          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#202020] focus:border-transparent transition-all ${
            verificationError ? "border-red-500 bg-red-50" : "border-gray-300"
          }`}
          placeholder="Enter your answer"
        />
        {verificationError && <p className="mt-2 text-sm text-red-600">Wrong answer. Please try again.</p>}
      </div>

      {/* Profile Picture (Optional) */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-[#202020] mb-2">
          Profile Picture <span className="text-[#666666] font-normal">(Optional)</span>
        </label>
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-[#202020] transition-colors"
        >
          {previewUrl ? (
            <div className="flex flex-col items-center">
              <Image
                src={previewUrl || "/placeholder.svg"}
                alt="Preview"
                width={80}
                height={80}
                className="rounded-full object-cover w-20 h-20 mb-2"
              />
              <p className="text-sm text-[#666666]">Click to change</p>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <svg className="w-10 h-10 text-gray-400 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              <p className="text-sm text-[#666666]">Click to upload photo</p>
            </div>
          )}
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        className="w-full py-3 bg-[#202020] text-white font-semibold rounded-lg transition-all duration-200 ease-in-out hover:scale-[1.02] hover:shadow-lg"
      >
        Register
      </button>
    </form>
  )
}
