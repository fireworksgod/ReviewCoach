export function HeroSection() {
  return (
    <section className="w-full bg-white py-24 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-5xl md:text-6xl font-extrabold text-[#202020] tracking-wide mb-6">Rate My Coach</h1>
        <p className="text-lg md:text-xl text-[#666666] font-normal leading-relaxed max-w-3xl mx-auto text-pretty">
          Rate My Coach is a site where you can learn about potential coaches and leave a review of coaches you have
          worked with in the past to help others make an informed decision
        </p>
      </div>
    </section>
  )
}
