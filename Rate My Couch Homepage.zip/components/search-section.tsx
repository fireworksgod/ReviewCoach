"use client"

import { useState } from "react"
import { Search } from "lucide-react"

export function SearchSection() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <section className="w-full bg-white pb-24 px-6">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#666666]" />
            <input
              type="text"
              placeholder="Search for a coach..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-14 pl-12 pr-4 bg-white border border-black/8 rounded text-[#333333] placeholder:text-[#666666] font-normal focus:outline-none focus:border-[#202020] transition-colors duration-200"
            />
          </div>
          <button className="h-14 px-8 bg-[#202020] text-white font-medium rounded shadow-sm transition-all duration-200 ease-in-out hover:scale-[1.03] hover:shadow-lg">
            Search
          </button>
        </div>
      </div>
    </section>
  )
}
