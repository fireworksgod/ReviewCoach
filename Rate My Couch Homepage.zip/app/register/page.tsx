import { Header } from "@/components/header"
import { RegisterForm } from "@/components/register-form"

export default function RegisterPage() {
  return (
    <main className="min-h-screen bg-white">
      <Header />
      <div className="flex justify-center py-12 px-4">
        <RegisterForm />
      </div>
    </main>
  )
}
