## Packages
framer-motion | Complex animations for hero and cards
lucide-react | Iconography (already in stack but confirming usage)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Montserrat", "sans-serif"],
}
