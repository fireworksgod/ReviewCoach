import { Link } from "wouter";
import { Header } from "@/components/Header";
import { SearchHero } from "@/components/SearchHero";
import { Footer } from "@/components/Footer";
import { CoachCard } from "@/components/CoachCard";
import { useQuery } from "@tanstack/react-query";

interface CoachWithRating {
  id: number;
  name: string;
  sport: string;
  instagram: string | null;
  imageUrl: string | null;
  calculatedRating: string;
  feedbackCount: number;
}

export default function Home() {
  const { data: coaches, isLoading } = useQuery<CoachWithRating[]>({
    queryKey: ["/api/coaches-with-ratings"],
  });

  // Mock featured coaches if DB is empty to show UI
  const displayCoaches = coaches && coaches.length > 0 ? coaches : [
    { id: 1, name: "Sarah Johnson", sport: "Tennis", instagram: "sarahj_tennis", calculatedRating: "5.0", feedbackCount: 42, imageUrl: null },
    { id: 2, name: "Mike Chen", sport: "Weightlifting", instagram: "mikechen_fit", calculatedRating: "4.0", feedbackCount: 15, imageUrl: null },
    { id: 3, name: "Jessica Davis", sport: "Swimming", instagram: "jess_swims", calculatedRating: "5.0", feedbackCount: 89, imageUrl: null },
    { id: 4, name: "David Wilson", sport: "Basketball", instagram: "dwilson_hoops", calculatedRating: "4.0", feedbackCount: 23, imageUrl: null }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      
      <main className="flex-grow">
        <SearchHero />
        
        {/* Featured Coaches */}
        <section className="py-16 md:py-24 bg-gray-50 border-t border-gray-100">
          <div className="container mx-auto px-4 max-w-7xl">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-extrabold text-[#202020] mb-2">Featured Coaches</h2>
                <p className="text-[#666666]">Discover highest-rated mentors trending this week</p>
              </div>
              <a href="/search" className="hidden md:block text-[#111111] font-semibold border-b-2 border-[#F5C518] hover:text-[#F5C518] transition-colors pb-1">
                View all coaches
              </a>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[1, 2, 3, 4].map(n => (
                  <div key={n} className="h-80 bg-white rounded-xl animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
                {displayCoaches.map((coach: any) => (
                  <CoachCard key={coach.id} coach={coach} />
                ))}
              </div>
            )}
            
            <div className="mt-12 text-center md:hidden">
              <button className="px-6 py-3 rounded-lg border border-gray-200 font-semibold text-[#333333]">
                View all coaches
              </button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-[#202020] text-white relative overflow-hidden">
           {/* Abstract Decoration */}
           <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
           
           <div className="container mx-auto px-4 max-w-4xl text-center relative z-10">
             <h2 className="text-3xl md:text-5xl font-extrabold mb-6">Are you a Coach?</h2>
             <p className="text-gray-300 text-lg mb-10 max-w-2xl mx-auto">
               Claim your profile today to start gathering reviews and growing your business. 
               Join thousands of coaches who use our platform.
             </p>
             <div className="flex flex-col sm:flex-row gap-4 justify-center">
               <Link href="/register">
                 <button className="px-8 py-4 rounded-lg bg-[#F5C518] text-[#111111] font-bold text-lg hover:bg-[#E6B800] transition-colors" data-testid="button-claim-profile">
                   Claim Profile
                 </button>
               </Link>
             </div>
           </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
